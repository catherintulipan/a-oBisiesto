﻿Public Class Form1
    Private Sub BtnContinuar_Click(sender As Object, e As EventArgs) Handles BtnContinuar.Click


        If (txtNombre.Text = "") Then
            MsgBox("No ingreso su nombre.")
        Else
            Form2.Show()
            MsgBox("Bienvenido " & txtNombre.Text)

        End If
    End Sub
End Class
