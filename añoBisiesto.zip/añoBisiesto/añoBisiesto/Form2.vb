﻿Public Class Form2
    Dim añoBisiesto As Integer
    Function Calcular(ByVal añoBisiesto As Integer) As Boolean
        Calcular = (añoBisiesto Mod 4 = 0)
        Return True Or False

    End Function
    Private Sub BtnAceptar_Click(sender As Object, e As EventArgs) Handles BtnAceptar.Click

        añoBisiesto = (txtAño.Text)
        If (añoBisiesto Mod 4 = 0) Then

            MsgBox("Es bisiesto")
        Else
            MsgBox("No es bisiesto")

        End If

    End Sub
End Class